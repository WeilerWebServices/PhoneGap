npm-stop(1) -- Stop a package
=============================

## SYNOPSIS

    npm stop [-- <args>]

## DESCRIPTION

This runs a package's "stop" script, if one was provided.

## SEE ALSO

* npm-run-script(1)
* npm-scripts(7)
* npm-test(1)
* npm-start(1)
* npm-restart(1)
